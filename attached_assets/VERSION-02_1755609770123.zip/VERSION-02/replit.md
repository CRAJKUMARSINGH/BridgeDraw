# Bridge Drafter Application

## Overview

Bridge Drafter is a specialized engineering application for creating, editing, and visualizing bridge cross-section drawings. The application is built as a full-stack web application with React frontend and Express backend, designed to replace traditional LISP-based AutoCAD workflows with a modern web interface. It supports importing engineering data from Excel files, interactive parameter adjustment, real-time drawing generation, and export capabilities for technical documentation.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **React with TypeScript**: Modern component-based UI using functional components and hooks
- **Vite Build System**: Fast development server with hot module replacement
- **UI Component Library**: Radix UI primitives with shadcn/ui styling system
- **Styling**: Tailwind CSS with CSS custom properties for theming
- **State Management**: React Query for server state, local state with useState/useReducer
- **Routing**: Wouter for lightweight client-side routing
- **Canvas Rendering**: HTML5 Canvas API with custom drawing engine for technical drawings

### Backend Architecture
- **Express.js Server**: RESTful API with TypeScript
- **Modular Storage Interface**: Abstracted storage layer supporting multiple implementations (currently in-memory, designed for future database integration)
- **File Processing**: Multer for file uploads with XLSX parsing for Excel data import
- **Route Organization**: Centralized route registration with proper error handling middleware
- **Development Tooling**: Vite integration for development mode with HMR support

### Data Architecture
- **Drizzle ORM**: Type-safe database schema definition and migrations
- **PostgreSQL**: Primary database (Neon serverless) with schema for projects and cross-section data
- **Zod Validation**: Runtime type validation for API inputs and data parsing
- **JSON Storage**: Complex engineering parameters stored as JSONB for flexibility
- **In-Memory Fallback**: Development storage implementation for rapid prototyping

### Drawing Engine
- **Custom Canvas Engine**: Specialized drawing system for engineering diagrams
- **Coordinate Transformation**: Mathematical conversion between engineering coordinates and canvas pixels
- **View Types**: Support for elevation, plan, and section views with different scaling
- **Interactive Features**: Zoom, pan, grid display, and dimension annotations
- **Export Capabilities**: Image export and PDF generation for technical documentation

### File Processing Pipeline
- **Excel Import**: XLSX parsing with validation for engineering data formats
- **Data Validation**: Multi-stage validation ensuring data integrity and engineering constraints
- **Parameter Calculation**: Automatic derivation of dependent engineering values (scales, angles, ratios)
- **Error Handling**: Comprehensive error reporting for invalid data formats or missing required fields

## External Dependencies

### Core Framework Dependencies
- **React Ecosystem**: React 18 with TypeScript, React Query for data fetching, React Hook Form for form management
- **Build Tools**: Vite for bundling and development, ESBuild for production builds
- **UI Libraries**: Radix UI for accessible primitives, Lucide React for icons, Tailwind CSS for styling

### Backend Dependencies
- **Express.js**: Web framework with middleware for CORS, body parsing, and file uploads
- **Database Layer**: Drizzle ORM with PostgreSQL driver, Neon serverless database
- **File Processing**: Multer for uploads, XLSX library for Excel parsing
- **Development**: tsx for TypeScript execution, nodemon equivalent functionality

### Specialized Libraries
- **Engineering Calculations**: Custom mathematical functions for coordinate transformations and engineering formulas
- **PDF Generation**: jsPDF for technical drawing exports
- **Date Handling**: date-fns for timestamp management
- **Validation**: Zod for schema validation and type safety

### Development and Deployment
- **Replit Integration**: Custom plugins for development environment and error overlay
- **Session Management**: Connect-pg-simple for PostgreSQL session storage
- **Environment Configuration**: Environment-based configuration for database connections and feature flags