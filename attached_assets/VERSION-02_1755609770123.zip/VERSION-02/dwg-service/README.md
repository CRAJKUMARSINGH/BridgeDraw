# BridgeGAD DWG Export Service

This service handles the generation of AutoCAD DWG files from bridge design data.

## Prerequisites

- Python 3.8 or higher
- pip (Python package manager)

## Setup

1. Create a virtual environment (recommended):
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

2. Install the required packages:
   ```bash
   pip install -r requirements.txt
   ```

## Running the Service

1. Start the FastAPI server:
   ```bash
   uvicorn main:app --reload
   ```

2. The service will be available at: http://localhost:8000

3. API Documentation (Swagger UI): http://localhost:8000/docs

## API Endpoints

- `POST /api/export/dwg` - Generate a DWG file from bridge data

## Development

### Testing

You can test the API using curl:

```bash
curl -X POST http://localhost:8000/api/export/dwg \
  -H "Content-Type: application/json" \
  -d '{"parameters": {"scale1": 100, "datum": 100.0, ...}, "crossSections": [...]}' \
  --output output.dwg
```

### Debugging

- Check the console output for error messages
- The service runs in debug mode with hot-reload enabled
- Detailed error messages are returned in the API response

## Deployment

For production deployment, consider using:
- Gunicorn with Uvicorn workers
- Nginx as a reverse proxy
- Process manager like PM2 or Supervisor
