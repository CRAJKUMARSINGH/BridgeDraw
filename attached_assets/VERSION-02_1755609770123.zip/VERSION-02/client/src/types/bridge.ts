export interface BridgeParameters {
  scale1: number; // Plan/elevation scale
  scale2: number; // Section scale
  skew: number; // Skew angle in degrees
  datum: number; // Datum level
  toprl: number; // Top RL
  left: number; // Start chainage
  right: number; // End chainage
  xincr: number; // X interval
  yincr: number; // Y interval
  noch: number; // Number of chainages
  
  // Calculated values
  hs: number;
  vs: number;
  vvs: number;
  hhs: number;
  skew1: number; // Skew in radians
  s: number; // sin(skew)
  c: number; // cos(skew)
  tn: number; // tan(skew)
  sc: number; // Scale ratio
}

export interface CrossSection {
  chainage: number;
  level: number;
  type?: string;
}

export interface BridgeProject {
  id?: string;
  name: string;
  description?: string;
  parameters: BridgeParameters;
  crossSectionData: CrossSection[];
  createdAt?: string;
  updatedAt?: string;
}

export interface DrawingConfig {
  viewType: 'elevation' | 'plan' | 'section';
  zoom: number;
  panX: number;
  panY: number;
  showGrid: boolean;
  showDimensions: boolean;
}

export interface ExportOptions {
  paperSize: 'A4' | 'A3' | 'A2' | 'A1' | 'A0';
  orientation: 'landscape' | 'portrait';
  includeTitleBlock: boolean;
  includeScaleInfo: boolean;
  includeGridLines: boolean;
  includeDataTable: boolean;
}
