import React, { useState } from 'react';
import { Save, FileText, Download, Ruler, Upload } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { BridgeGADCanvas } from '@/components/BridgeGADCanvas';
import { GADParametersPanel } from '@/components/GADParametersPanel';
import { GADParameters } from '@/lib/bridgeGAD';
import jsPDF from 'jspdf';
import * as XLSX from 'xlsx';

// Default GAD parameters based on LISP sample data
const defaultGADParameters: GADParameters = {
  // Basic parameters
  scale1: 100,
  datum: 100.000,
  left: 0.000,
  right: 200.000,
  toprl: 120.000,
  skew: 0.000,
  
  // Grid spacing (from LISP: d1 = 20mm)
  d1: 20,
  xincr: 10.0,
  yincr: 2.0,
  
  // Bridge data
  nspan: 2,
  lbridge: 150.0,
  abtl: 50.0,
  RTL: 108.0,
  sofl: 105.5,
  
  // Deck details
  kerbw: 0.300,
  kerbd: 0.150,
  ccbr: 7.500,
  slbthc: 0.800,
  slbthe: 0.500,
  slbtht: 0.150,
  
  // Pier details
  capt: 107.0,
  capb: 106.5,
  capw: 2.500,
  piertw: 1.500,
  battr: 10.0,
  pierst: 5.0,
  
  // Cross-section data from sample file
  crossSections: [
    { chainage: 0.000, level: 100.500 },
    { chainage: 10.000, level: 101.200 },
    { chainage: 20.000, level: 102.000 },
    { chainage: 30.000, level: 102.500 },
    { chainage: 40.000, level: 103.000 },
    { chainage: 50.000, level: 103.200 },
    { chainage: 60.000, level: 103.500 },
    { chainage: 70.000, level: 104.000 },
    { chainage: 80.000, level: 104.200 },
    { chainage: 90.000, level: 104.500 },
    { chainage: 100.000, level: 105.000 },
    { chainage: 110.000, level: 105.200 },
    { chainage: 120.000, level: 105.500 },
    { chainage: 130.000, level: 106.000 },
    { chainage: 140.000, level: 106.200 },
    { chainage: 150.000, level: 106.500 },
    { chainage: 160.000, level: 107.000 },
    { chainage: 170.000, level: 107.200 },
    { chainage: 180.000, level: 107.500 },
    { chainage: 190.000, level: 108.000 },
    { chainage: 200.000, level: 108.500 }
  ],
  
  // Span data
  spans: [
    {
      length: 75.0,
      futrl: 98.0,
      futd: 3.0,
      futw: 4.0,
      futl: 8.0
    },
    {
      length: 75.0,
      futrl: 97.5,
      futd: 3.5,
      futw: 4.5,
      futl: 8.5
    }
  ]
};
];

export default function BridgeDrafter() {
  const [parameters, setParameters] = useState<BridgeParameters>(defaultParameters);
  const [crossSections, setCrossSections] = useState<CrossSection[]>(defaultCrossSections);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [lastSaved, setLastSaved] = useState<string>('Never');
  const { toast } = useToast();

  const handleDataParsed = (data: ParsedExcelData) => {
    setParameters(data.parameters);
    setCrossSections(data.crossSections);
    toast({
      title: "Data Loaded",
      description: "Excel data has been successfully loaded and applied.",
    });
  };

  const handleParametersChange = (newParameters: BridgeParameters) => {
    setParameters(newParameters);
  };

  const handleCrossSectionAdd = () => {
    const lastSection = crossSections[crossSections.length - 1];
    const newChainage = lastSection ? lastSection.chainage + parameters.xincr : parameters.left;
    
    setCrossSections(prev => [
      ...prev,
      {
        chainage: newChainage,
        level: parameters.datum,
        type: 'Ground'
      }
    ]);
  };

  const handleSaveProject = async () => {
    try {
      const project: BridgeProject = {
        name: `Bridge Project ${new Date().toLocaleDateString()}`,
        description: 'Generated from Bridge GAD Drafter',
        parameters,
        crossSectionData: crossSections
      };

      // In a real app, this would save to backend
      const response = await fetch('/api/projects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(project)
      });

      if (response.ok) {
        setLastSaved(new Date().toLocaleTimeString());
        toast({
          title: "Project Saved",
          description: "Your bridge project has been saved successfully.",
        });
      } else {
        throw new Error('Failed to save project');
      }
    } catch (error) {
      toast({
        title: "Save Failed",
        description: "Failed to save project. Please try again.",
        variant: "destructive"
      });
    }
  };

  const handleExportPDF = async (options: ExportOptions) => {
    try {
      // Get the canvas element
      const canvas = document.querySelector('canvas');
      if (!canvas) throw new Error('Drawing canvas not found');
      
      // Convert canvas to image
      const imageData = canvas.toDataURL('image/png');
      
      // Create PDF with proper dimensions
      const pdf = new jsPDF({
        orientation: options.orientation,
        unit: 'mm',
        format: options.paperSize.toLowerCase() as any
      });

      // Calculate dimensions
      const imgProps = pdf.getImageProperties(imageData);
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;

      // Add the image
      pdf.addImage(imageData, 'PNG', 0, 0, pdfWidth, pdfHeight);

      // Add title block if requested
      if (options.includeTitleBlock) {
        pdf.setFontSize(16);
        pdf.text('Bridge Engineering Drawing', 20, 20);
        pdf.setFontSize(10);
        pdf.text(`Generated: ${new Date().toLocaleString()}`, 20, 30);
        pdf.text(`Scale: 1:${parameters.scale1}`, 20, 35);
      }

      // Add parameters table if requested
      if (options.includeDataTable) {
        let yPos = options.includeTitleBlock ? 50 : 20;
        pdf.setFontSize(12);
        pdf.text('Design Parameters', 20, yPos);
        yPos += 10;
        
        pdf.setFontSize(8);
        const parameterData = [
          ['Scale 1 (Plan/Elevation)', parameters.scale1.toString()],
          ['Datum Level (m)', parameters.datum.toString()],
          ['Top RL (m)', parameters.toprl.toString()],
          ['Start Chainage (m)', parameters.left.toString()],
          ['End Chainage (m)', parameters.right.toString()],
        ];

        parameterData.forEach(([label, value], index) => {
          pdf.text(`${label}: ${value}`, 20, yPos + (index * 5));
        });
      }

      // Add metadata
      pdf.setProperties({
        title: `Bridge Drawing - ${new Date().toLocaleDateString()}`,
        subject: 'Bridge Engineering Drawing',
        author: 'BridgeGAD Drafter'
      });

      // Save the PDF
      pdf.save(`bridge-drawing-${new Date().toISOString().split('T')[0]}.pdf`);
      
      toast({
        title: "PDF Exported",
        description: "Bridge drawing has been exported as PDF.",
      });
    } catch (error) {
      toast({
        title: "Export Failed",
        description: "Failed to export PDF. Please try again.",
        variant: "destructive"
      });
    }
  };

  const handleExportDWG = async () => {
    try {
      // Prepare bridge data for export
      const bridgeData = {
        parameters,
        crossSections: crossSections.map(cs => ({
          chainage: cs.chainage,
          level: cs.level,
          type: cs.type || 'Ground'
        }))
      };

      // Call the DWG export service
      const response = await fetch('http://localhost:8000/api/export/dwg', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(bridgeData)
      });

      if (!response.ok) {
        throw new Error('DWG export failed');
      }

      // Get the blob and create download
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      
      // Get filename from Content-Disposition header or use default
      const contentDisposition = response.headers.get('Content-Disposition');
      let filename = `bridge-export-${new Date().toISOString().split('T')[0]}.dwg`;
      
      if (contentDisposition) {
        const filenameMatch = contentDisposition.match(/filename="?([^"]+)"?/);
        if (filenameMatch && filenameMatch[1]) {
          filename = filenameMatch[1];
        }
      }
      
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);

      toast({
        title: "DWG Exported",
        description: "Bridge drawing has been exported as DWG.",
      });
    } catch (error) {
      console.error('DWG Export Error:', error);
      toast({
        title: "Export Failed",
        description: `Failed to export DWG: ${error.message}`,
        variant: "destructive"
      });
    }
  };

  const handleExportImage = (imageData: string) => {
    const link = document.createElement('a');
    link.download = `bridge-drawing-${Date.now()}.png`;
    link.href = imageData;
    link.click();
    
    toast({
      title: "Image Exported",
      description: "Drawing has been exported as PNG image.",
    });
  };

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-full px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Ruler className="text-blue-600 text-2xl" />
              <h1 className="text-2xl font-bold text-gray-900">Bridge GAD Drafter</h1>
              <span className="text-sm text-gray-500 bg-gray-100 px-2 py-1 rounded">v2.0</span>
            </div>
            <div className="flex items-center space-x-4">
              <Button
                onClick={handleSaveProject}
                className="flex items-center space-x-2 bg-blue-600 text-white hover:bg-blue-700"
              >
                <Save className="h-4 w-4" />
                <span>Save Project</span>
              </Button>
              <Button
                onClick={() => setIsExportModalOpen(true)}
                className="flex items-center space-x-2 bg-orange-500 text-white hover:bg-orange-600"
              >
                <FileText className="h-4 w-4" />
                <span>Export PDF</span>
              </Button>
              <Button
                onClick={handleExportDWG}
                className="flex items-center space-x-2 bg-gray-600 text-white hover:bg-gray-700"
              >
                <Download className="h-4 w-4" />
                <span>Export DWG</span>
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex h-screen pt-16">
        {/* Sidebar */}
        <aside className="w-80 bg-white shadow-lg border-r border-gray-200 overflow-y-auto">
          {/* File Upload Section */}
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Input Data</h2>
            <FileUpload onDataParsed={handleDataParsed} />
          </div>

          {/* All Variables Display */}
          <div className="p-6 border-b border-gray-200">
            <VariablesDisplay
              parameters={parameters}
              crossSections={crossSections}
            />
          </div>

          {/* Parameters Panel */}
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Edit Parameters</h2>
            <ParametersPanel
              parameters={parameters}
              crossSections={crossSections}
              onParametersChange={handleParametersChange}
              onCrossSectionAdd={handleCrossSectionAdd}
            />
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 flex flex-col">
          <DrawingCanvas
            parameters={parameters}
            crossSections={crossSections}
            onExportImage={handleExportImage}
          />

          {/* Status Bar */}
          <div className="bg-white border-t border-gray-200 px-6 py-2">
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span className="text-gray-600">Calculations: Updated</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                  <span className="text-gray-600">Drawing: Live</span>
                </div>
              </div>
              <div className="flex items-center space-x-4 text-gray-500">
                <span>Last saved: {lastSaved}</span>
                <span>|</span>
                <span>Elements: <span className="font-mono">{crossSections.length}</span></span>
              </div>
            </div>
          </div>
        </main>
      </div>

      {/* Export Modal */}
      <ExportModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        onExport={handleExportPDF}
      />
    </div>
  );
}
