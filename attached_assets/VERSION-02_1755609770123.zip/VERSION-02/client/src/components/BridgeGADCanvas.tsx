import React, { useRef, useEffect } from 'react';
import { BridgeGADEngine, GADParameters } from '@/lib/bridgeGAD';

interface BridgeGADCanvasProps {
  parameters: GADParameters;
  width?: number;
  height?: number;
}

export const BridgeGADCanvas: React.FC<BridgeGADCanvasProps> = ({
  parameters,
  width = 1200,
  height = 800
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<BridgeGADEngine | null>(null);

  useEffect(() => {
    if (canvasRef.current) {
      if (!engineRef.current) {
        engineRef.current = new BridgeGADEngine(canvasRef.current);
      }
      engineRef.current.drawGAD(parameters);
    }
  }, [parameters]);

  return (
    <div className="w-full border rounded-lg overflow-hidden">
      <canvas
        ref={canvasRef}
        width={width}
        height={height}
        className="w-full h-auto bg-white"
        style={{ maxWidth: '100%', height: 'auto' }}
      />
    </div>
  );
};