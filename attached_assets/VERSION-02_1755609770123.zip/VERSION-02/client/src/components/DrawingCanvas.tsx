import React, { useRef, useEffect, useState, useCallback } from 'react';
import { BridgeParameters, CrossSection, DrawingConfig } from '@/types/bridge';
import { DrawingEngine } from '@/lib/drawingEngine';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { ZoomIn, ZoomOut, Maximize, Home } from 'lucide-react';

interface DrawingCanvasProps {
  parameters: BridgeParameters;
  crossSections: CrossSection[];
  onExportImage: (imageData: string) => void;
}

export function DrawingCanvas({ parameters, crossSections, onExportImage }: DrawingCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<DrawingEngine | null>(null);
  const [config, setConfig] = useState<DrawingConfig>({
    viewType: 'elevation',
    zoom: 1,
    panX: 0,
    panY: 0,
    showGrid: true,
    showDimensions: true
  });
  const [cursorPos, setCursorPos] = useState<string>('Ch: 0.0, RL: 100.0');

  // Initialize drawing engine
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    // Set canvas size
    const resizeCanvas = () => {
      const rect = canvas.parentElement?.getBoundingClientRect();
      if (rect) {
        canvas.width = rect.width;
        canvas.height = rect.height;
      }
    };

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    try {
      engineRef.current = new DrawingEngine(canvas, parameters);
      engineRef.current.updateConfig(config);
      engineRef.current.draw(crossSections);
    } catch (error) {
      console.error('Failed to initialize drawing engine:', error);
    }

    return () => {
      window.removeEventListener('resize', resizeCanvas);
    };
  }, []);

  // Update drawing when parameters or cross-sections change
  useEffect(() => {
    if (engineRef.current) {
      engineRef.current.updateParameters(parameters);
      engineRef.current.draw(crossSections);
    }
  }, [parameters, crossSections]);

  // Update drawing when config changes
  useEffect(() => {
    if (engineRef.current) {
      engineRef.current.updateConfig(config);
      engineRef.current.draw(crossSections);
    }
  }, [config, crossSections]);

  const handleViewTypeChange = (viewType: 'elevation' | 'plan' | 'section') => {
    setConfig(prev => ({ ...prev, viewType }));
  };

  const handleZoom = (direction: 'in' | 'out') => {
    setConfig(prev => ({
      ...prev,
      zoom: direction === 'in' ? Math.min(prev.zoom * 1.2, 5) : Math.max(prev.zoom * 0.8, 0.1)
    }));
  };

  const handleFitToScreen = () => {
    setConfig(prev => ({ ...prev, zoom: 1, panX: 0, panY: 0 }));
  };

  const handleResetView = () => {
    setConfig({
      viewType: 'elevation',
      zoom: 1,
      panX: 0,
      panY: 0,
      showGrid: true,
      showDimensions: true
    });
  };

  const handleMouseMove = useCallback((event: React.MouseEvent<HTMLCanvasElement>) => {
    if (engineRef.current) {
      const coords = engineRef.current.getCursorPosition(event.clientX, event.clientY);
      setCursorPos(`Ch: ${coords.chainage.toFixed(1)}, RL: ${coords.level.toFixed(1)}`);
    }
  }, []);

  const handleExportImage = () => {
    if (engineRef.current) {
      const imageData = engineRef.current.exportAsImage();
      onExportImage(imageData);
    }
  };

  return (
    <div className="flex flex-col h-full">
      {/* Drawing Controls */}
      <div className="bg-white border-b border-gray-200 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <h2 className="text-lg font-semibold text-gray-900">Drawing Canvas</h2>
            <div className="flex items-center space-x-2 text-sm text-gray-600">
              <span>View:</span>
              <Select value={config.viewType} onValueChange={handleViewTypeChange}>
                <SelectTrigger className="w-32 h-8">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="elevation">Elevation</SelectItem>
                  <SelectItem value="plan">Plan</SelectItem>
                  <SelectItem value="section">Cross-Section</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            {/* Zoom Controls */}
            <div className="flex items-center space-x-1 bg-gray-100 rounded-lg p-1">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleZoom('out')}
                className="h-8 w-8 p-0"
              >
                <ZoomOut className="h-4 w-4 text-gray-600" />
              </Button>
              <span className="px-2 text-sm font-mono text-gray-700">
                {Math.round(config.zoom * 100)}%
              </span>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleZoom('in')}
                className="h-8 w-8 p-0"
              >
                <ZoomIn className="h-4 w-4 text-gray-600" />
              </Button>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleFitToScreen}
              className="h-8 w-8 p-0 bg-gray-100 hover:bg-gray-200"
            >
              <Maximize className="h-4 w-4 text-gray-600" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleResetView}
              className="h-8 w-8 p-0 bg-gray-100 hover:bg-gray-200"
            >
              <Home className="h-4 w-4 text-gray-600" />
            </Button>
          </div>
        </div>
      </div>

      {/* Drawing Canvas */}
      <div className="flex-1 relative overflow-hidden bg-gray-50">
        <canvas
          ref={canvasRef}
          className="absolute inset-0 w-full h-full cursor-crosshair"
          onMouseMove={handleMouseMove}
          style={{
            background: 'radial-gradient(circle, #ccc 1px, transparent 1px)',
            backgroundSize: '20px 20px'
          }}
        />
        
        {/* Drawing Information Panel */}
        <div className="absolute bottom-4 left-4 bg-white rounded-lg shadow-lg p-4 max-w-xs">
          <h3 className="font-semibold text-gray-900 mb-2">Drawing Info</h3>
          <div className="space-y-1 text-xs">
            <div className="flex justify-between">
              <span className="text-gray-600">Current Scale:</span>
              <span className="font-mono text-blue-600 font-semibold">1:{parameters.scale1}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">View Type:</span>
              <span className="font-semibold text-gray-800 capitalize">{config.viewType}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Grid Size:</span>
              <span className="font-mono text-gray-700">{parameters.xincr}m</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Cursor Pos:</span>
              <span className="font-mono text-gray-700">{cursorPos}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
