import React, { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, FileSpreadsheet, AlertCircle, CheckCircle } from 'lucide-react';
import { parseExcelFile, validateExcelData, ParsedExcelData } from '@/lib/excelParser';
import { useToast } from '@/hooks/use-toast';

interface FileUploadProps {
  onDataParsed: (data: ParsedExcelData) => void;
}

export function FileUpload({ onDataParsed }: FileUploadProps) {
  const [status, setStatus] = useState<'ready' | 'loading' | 'success' | 'error'>('ready');
  const [fileName, setFileName] = useState<string>('');
  const { toast } = useToast();

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (!file) return;

    setStatus('loading');
    setFileName(file.name);

    try {
      const parsedData = await parseExcelFile(file);
      const validationErrors = validateExcelData(parsedData);
      
      if (validationErrors.length > 0) {
        setStatus('error');
        toast({
          title: "Validation Error",
          description: validationErrors.join(', '),
          variant: "destructive"
        });
        return;
      }

      setStatus('success');
      onDataParsed(parsedData);
      toast({
        title: "File Parsed Successfully",
        description: `Loaded ${parsedData.crossSections.length} cross-sections`,
      });
    } catch (error) {
      setStatus('error');
      toast({
        title: "Parse Error",
        description: (error as Error).message,
        variant: "destructive"
      });
    }
  }, [onDataParsed, toast]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'],
      'application/vnd.ms-excel': ['.xls']
    },
    multiple: false
  });

  const getStatusIcon = () => {
    switch (status) {
      case 'loading':
        return <div className="animate-spin h-8 w-8 border-2 border-blue-600 border-t-transparent rounded-full" />;
      case 'success':
        return <CheckCircle className="h-8 w-8 text-green-600" />;
      case 'error':
        return <AlertCircle className="h-8 w-8 text-red-600" />;
      default:
        return <FileSpreadsheet className="h-8 w-8 text-green-600" />;
    }
  };

  const getStatusText = () => {
    switch (status) {
      case 'loading':
        return 'Processing...';
      case 'success':
        return 'Ready';
      case 'error':
        return 'Error';
      default:
        return 'Ready';
    }
  };

  const getStatusColor = () => {
    switch (status) {
      case 'success':
        return 'text-green-600';
      case 'error':
        return 'text-red-600';
      case 'loading':
        return 'text-blue-600';
      default:
        return 'text-gray-600';
    }
  };

  return (
    <div className="space-y-4">
      <div
        {...getRootProps()}
        className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors ${
          isDragActive 
            ? 'border-blue-500 bg-blue-50' 
            : status === 'error'
            ? 'border-red-300 bg-red-50'
            : status === 'success'
            ? 'border-green-300 bg-green-50'
            : 'border-gray-300 hover:border-blue-500'
        }`}
      >
        <input {...getInputProps()} />
        <div className="flex flex-col items-center space-y-2">
          {getStatusIcon()}
          <p className="text-sm text-gray-600">
            {isDragActive
              ? 'Drop the Excel file here'
              : fileName
              ? `${fileName}`
              : 'Drop Excel file here or click to browse'
            }
          </p>
          <p className="text-xs text-gray-500">Supports .xlsx, .xls formats</p>
        </div>
      </div>
      
      <div className="flex items-center justify-between">
        <span className="text-sm text-gray-600">Status:</span>
        <span className={`text-sm font-medium ${getStatusColor()}`}>
          {getStatusText()}
        </span>
      </div>
    </div>
  );
}
