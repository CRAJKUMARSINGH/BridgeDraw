import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { GADParameters } from '@/lib/bridgeGAD';

interface GADParametersPanelProps {
  parameters: GADParameters;
  onChange: (params: GADParameters) => void;
  onAddSpan: () => void;
  onRemoveSpan: (index: number) => void;
}

export const GADParametersPanel: React.FC<GADParametersPanelProps> = ({
  parameters,
  onChange,
  onAddSpan,
  onRemoveSpan
}) => {
  const updateParameter = (key: keyof GADParameters, value: any) => {
    onChange({ ...parameters, [key]: value });
  };

  const updateSpan = (index: number, field: string, value: number) => {
    const newSpans = [...parameters.spans];
    newSpans[index] = { ...newSpans[index], [field]: value };
    onChange({ ...parameters, spans: newSpans });
  };

  const updateCrossSection = (index: number, field: 'chainage' | 'level', value: number) => {
    const newCrossSections = [...parameters.crossSections];
    newCrossSections[index] = { ...newCrossSections[index], [field]: value };
    onChange({ ...parameters, crossSections: newCrossSections });
  };

  return (
    <Card className="w-full h-full">
      <CardHeader>
        <CardTitle>Bridge GAD Parameters</CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="basic" className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="basic">Basic</TabsTrigger>
            <TabsTrigger value="layout">Layout</TabsTrigger>
            <TabsTrigger value="bridge">Bridge</TabsTrigger>
            <TabsTrigger value="spans">Spans</TabsTrigger>
            <TabsTrigger value="crosssection">Cross Section</TabsTrigger>
          </TabsList>

          <TabsContent value="basic">
            <ScrollArea className="h-[400px]">
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="scale1">Scale (1:)</Label>
                    <Input
                      id="scale1"
                      type="number"
                      value={parameters.scale1}
                      onChange={(e) => updateParameter('scale1', Number(e.target.value))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="datum">Datum Level</Label>
                    <Input
                      id="datum"
                      type="number"
                      step="0.001"
                      value={parameters.datum}
                      onChange={(e) => updateParameter('datum', Number(e.target.value))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="skew">Skew Angle (°)</Label>
                    <Input
                      id="skew"
                      type="number"
                      value={parameters.skew}
                      onChange={(e) => updateParameter('skew', Number(e.target.value))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="toprl">Top RL</Label>
                    <Input
                      id="toprl"
                      type="number"
                      step="0.001"
                      value={parameters.toprl}
                      onChange={(e) => updateParameter('toprl', Number(e.target.value))}
                    />
                  </div>
                </div>
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="layout">
            <ScrollArea className="h-[400px]">
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="left">Left Boundary</Label>
                    <Input
                      id="left"
                      type="number"
                      step="0.001"
                      value={parameters.left}
                      onChange={(e) => updateParameter('left', Number(e.target.value))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="right">Right Boundary</Label>
                    <Input
                      id="right"
                      type="number"
                      step="0.001"
                      value={parameters.right}
                      onChange={(e) => updateParameter('right', Number(e.target.value))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="d1">Grid Spacing (mm)</Label>
                    <Input
                      id="d1"
                      type="number"
                      value={parameters.d1}
                      onChange={(e) => updateParameter('d1', Number(e.target.value))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="xincr">Chainage Increment</Label>
                    <Input
                      id="xincr"
                      type="number"
                      step="0.1"
                      value={parameters.xincr}
                      onChange={(e) => updateParameter('xincr', Number(e.target.value))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="yincr">Level Increment</Label>
                    <Input
                      id="yincr"
                      type="number"
                      step="0.1"
                      value={parameters.yincr}
                      onChange={(e) => updateParameter('yincr', Number(e.target.value))}
                    />
                  </div>
                </div>
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="bridge">
            <ScrollArea className="h-[400px]">
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="nspan">Number of Spans</Label>
                    <Input
                      id="nspan"
                      type="number"
                      value={parameters.nspan}
                      onChange={(e) => updateParameter('nspan', Number(e.target.value))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="lbridge">Bridge Length</Label>
                    <Input
                      id="lbridge"
                      type="number"
                      step="0.1"
                      value={parameters.lbridge}
                      onChange={(e) => updateParameter('lbridge', Number(e.target.value))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="abtl">Left Abutment Chainage</Label>
                    <Input
                      id="abtl"
                      type="number"
                      step="0.001"
                      value={parameters.abtl}
                      onChange={(e) => updateParameter('abtl', Number(e.target.value))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="RTL">Road Top Level</Label>
                    <Input
                      id="RTL"
                      type="number"
                      step="0.001"
                      value={parameters.RTL}
                      onChange={(e) => updateParameter('RTL', Number(e.target.value))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="sofl">Soffit Level</Label>
                    <Input
                      id="sofl"
                      type="number"
                      step="0.001"
                      value={parameters.sofl}
                      onChange={(e) => updateParameter('sofl', Number(e.target.value))}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <h4 className="font-medium">Deck Details</h4>
                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <Label htmlFor="kerbw">Kerb Width</Label>
                      <Input
                        id="kerbw"
                        type="number"
                        step="0.001"
                        value={parameters.kerbw}
                        onChange={(e) => updateParameter('kerbw', Number(e.target.value))}
                      />
                    </div>
                    <div>
                      <Label htmlFor="kerbd">Kerb Depth</Label>
                      <Input
                        id="kerbd"
                        type="number"
                        step="0.001"
                        value={parameters.kerbd}
                        onChange={(e) => updateParameter('kerbd', Number(e.target.value))}
                      />
                    </div>
                    <div>
                      <Label htmlFor="ccbr">Carriageway Width</Label>
                      <Input
                        id="ccbr"
                        type="number"
                        step="0.001"
                        value={parameters.ccbr}
                        onChange={(e) => updateParameter('ccbr', Number(e.target.value))}
                      />
                    </div>
                    <div>
                      <Label htmlFor="slbthc">Slab Thickness (Centre)</Label>
                      <Input
                        id="slbthc"
                        type="number"
                        step="0.001"
                        value={parameters.slbthc}
                        onChange={(e) => updateParameter('slbthc', Number(e.target.value))}
                      />
                    </div>
                    <div>
                      <Label htmlFor="slbthe">Slab Thickness (Edge)</Label>
                      <Input
                        id="slbthe"
                        type="number"
                        step="0.001"
                        value={parameters.slbthe}
                        onChange={(e) => updateParameter('slbthe', Number(e.target.value))}
                      />
                    </div>
                    <div>
                      <Label htmlFor="slbtht">Slab Thickness (Tip)</Label>
                      <Input
                        id="slbtht"
                        type="number"
                        step="0.001"
                        value={parameters.slbtht}
                        onChange={(e) => updateParameter('slbtht', Number(e.target.value))}
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <h4 className="font-medium">Pier Details</h4>
                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <Label htmlFor="capt">Cap Top RL</Label>
                      <Input
                        id="capt"
                        type="number"
                        step="0.001"
                        value={parameters.capt}
                        onChange={(e) => updateParameter('capt', Number(e.target.value))}
                      />
                    </div>
                    <div>
                      <Label htmlFor="capb">Cap Bottom RL</Label>
                      <Input
                        id="capb"
                        type="number"
                        step="0.001"
                        value={parameters.capb}
                        onChange={(e) => updateParameter('capb', Number(e.target.value))}
                      />
                    </div>
                    <div>
                      <Label htmlFor="capw">Cap Width</Label>
                      <Input
                        id="capw"
                        type="number"
                        step="0.001"
                        value={parameters.capw}
                        onChange={(e) => updateParameter('capw', Number(e.target.value))}
                      />
                    </div>
                    <div>
                      <Label htmlFor="piertw">Pier Top Width</Label>
                      <Input
                        id="piertw"
                        type="number"
                        step="0.001"
                        value={parameters.piertw}
                        onChange={(e) => updateParameter('piertw', Number(e.target.value))}
                      />
                    </div>
                    <div>
                      <Label htmlFor="battr">Pier Batter</Label>
                      <Input
                        id="battr"
                        type="number"
                        step="0.1"
                        value={parameters.battr}
                        onChange={(e) => updateParameter('battr', Number(e.target.value))}
                      />
                    </div>
                    <div>
                      <Label htmlFor="pierst">Pier Straight Length</Label>
                      <Input
                        id="pierst"
                        type="number"
                        step="0.001"
                        value={parameters.pierst}
                        onChange={(e) => updateParameter('pierst', Number(e.target.value))}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="spans">
            <ScrollArea className="h-[400px]">
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h4 className="font-medium">Span Data</h4>
                  <Button onClick={onAddSpan} size="sm">Add Span</Button>
                </div>
                
                {parameters.spans.map((span, index) => (
                  <Card key={index} className="p-3">
                    <div className="flex justify-between items-center mb-2">
                      <h5 className="font-medium">Span {index + 1}</h5>
                      <Button 
                        onClick={() => onRemoveSpan(index)} 
                        variant="destructive" 
                        size="sm"
                        disabled={parameters.spans.length <= 1}
                      >
                        Remove
                      </Button>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <Label>Span Length</Label>
                        <Input
                          type="number"
                          step="0.1"
                          value={span.length}
                          onChange={(e) => updateSpan(index, 'length', Number(e.target.value))}
                        />
                      </div>
                      <div>
                        <Label>Founding RL</Label>
                        <Input
                          type="number"
                          step="0.001"
                          value={span.futrl}
                          onChange={(e) => updateSpan(index, 'futrl', Number(e.target.value))}
                        />
                      </div>
                      <div>
                        <Label>Footing Depth</Label>
                        <Input
                          type="number"
                          step="0.001"
                          value={span.futd}
                          onChange={(e) => updateSpan(index, 'futd', Number(e.target.value))}
                        />
                      </div>
                      <div>
                        <Label>Footing Width</Label>
                        <Input
                          type="number"
                          step="0.001"
                          value={span.futw}
                          onChange={(e) => updateSpan(index, 'futw', Number(e.target.value))}
                        />
                      </div>
                      <div>
                        <Label>Footing Length</Label>
                        <Input
                          type="number"
                          step="0.001"
                          value={span.futl}
                          onChange={(e) => updateSpan(index, 'futl', Number(e.target.value))}
                        />
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="crosssection">
            <ScrollArea className="h-[400px]">
              <div className="space-y-4">
                <h4 className="font-medium">Cross Section Data</h4>
                {parameters.crossSections.map((cs, index) => (
                  <div key={index} className="grid grid-cols-3 gap-2 items-center">
                    <div>
                      <Label>Chainage</Label>
                      <Input
                        type="number"
                        step="0.001"
                        value={cs.chainage}
                        onChange={(e) => updateCrossSection(index, 'chainage', Number(e.target.value))}
                      />
                    </div>
                    <div>
                      <Label>Level</Label>
                      <Input
                        type="number"
                        step="0.001"
                        value={cs.level}
                        onChange={(e) => updateCrossSection(index, 'level', Number(e.target.value))}
                      />
                    </div>
                    <div className="text-sm text-gray-600">
                      Point {index + 1}
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};