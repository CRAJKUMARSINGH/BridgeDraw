import React from 'react';
import { BridgeParameters, CrossSection } from '@/types/bridge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';

interface ParametersPanelProps {
  parameters: BridgeParameters;
  crossSections: CrossSection[];
  onParametersChange: (parameters: BridgeParameters) => void;
  onCrossSectionAdd: () => void;
}

export function ParametersPanel({
  parameters,
  crossSections,
  onParametersChange,
  onCrossSectionAdd
}: ParametersPanelProps) {
  const handleParameterChange = (key: keyof BridgeParameters, value: number) => {
    const updated = { ...parameters, [key]: value };
    
    // Recalculate derived values
    updated.hs = 1;
    updated.vs = 1;
    updated.vvs = 1000.0 / updated.vs;
    updated.hhs = 1000.0 / updated.hs;
    updated.skew1 = updated.skew * 0.0174532;
    updated.s = Math.sin(updated.skew1);
    updated.c = Math.cos(updated.skew1);
    updated.tn = updated.s / updated.c;
    updated.sc = updated.scale1 / updated.scale2;
    
    onParametersChange(updated);
  };

  return (
    <div className="space-y-6">
      {/* Scale Parameters */}
      <div className="bg-gray-50 p-3 rounded-lg">
        <h3 className="text-sm font-semibold text-gray-700 mb-3">Scale Settings</h3>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label htmlFor="scale1" className="text-xs text-gray-600">Plan/Elevation Scale:</Label>
            <Input
              id="scale1"
              type="number"
              value={parameters.scale1}
              onChange={(e) => handleParameterChange('scale1', parseFloat(e.target.value) || 0)}
              className="h-8 text-xs font-mono text-blue-600 font-semibold"
            />
          </div>
          <div>
            <Label htmlFor="scale2" className="text-xs text-gray-600">Section Scale:</Label>
            <Input
              id="scale2"
              type="number"
              value={parameters.scale2}
              onChange={(e) => handleParameterChange('scale2', parseFloat(e.target.value) || 0)}
              className="h-8 text-xs font-mono text-blue-600 font-semibold"
            />
          </div>
        </div>
      </div>

      {/* Geometry Parameters */}
      <div className="bg-gray-50 p-3 rounded-lg">
        <h3 className="text-sm font-semibold text-gray-700 mb-3">Geometry</h3>
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <Label htmlFor="skew" className="text-xs text-gray-600">Skew Angle (°):</Label>
            <Input
              id="skew"
              type="number"
              step="0.1"
              value={parameters.skew}
              onChange={(e) => handleParameterChange('skew', parseFloat(e.target.value) || 0)}
              className="w-20 h-8 text-xs font-mono text-blue-600 font-semibold"
            />
          </div>
          <div className="flex justify-between items-center">
            <Label htmlFor="datum" className="text-xs text-gray-600">Datum Level (m):</Label>
            <Input
              id="datum"
              type="number"
              step="0.01"
              value={parameters.datum}
              onChange={(e) => handleParameterChange('datum', parseFloat(e.target.value) || 0)}
              className="w-20 h-8 text-xs font-mono text-blue-600 font-semibold"
            />
          </div>
          <div className="flex justify-between items-center">
            <Label htmlFor="toprl" className="text-xs text-gray-600">Top RL (m):</Label>
            <Input
              id="toprl"
              type="number"
              step="0.01"
              value={parameters.toprl}
              onChange={(e) => handleParameterChange('toprl', parseFloat(e.target.value) || 0)}
              className="w-20 h-8 text-xs font-mono text-blue-600 font-semibold"
            />
          </div>
        </div>
      </div>

      {/* Chainage Parameters */}
      <div className="bg-gray-50 p-3 rounded-lg">
        <h3 className="text-sm font-semibold text-gray-700 mb-3">Chainage Settings</h3>
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <Label htmlFor="left" className="text-xs text-gray-600">Start Ch. (m):</Label>
            <Input
              id="left"
              type="number"
              step="0.01"
              value={parameters.left}
              onChange={(e) => handleParameterChange('left', parseFloat(e.target.value) || 0)}
              className="w-24 h-8 text-xs font-mono text-blue-600 font-semibold"
            />
          </div>
          <div className="flex justify-between items-center">
            <Label htmlFor="right" className="text-xs text-gray-600">End Ch. (m):</Label>
            <Input
              id="right"
              type="number"
              step="0.01"
              value={parameters.right}
              onChange={(e) => handleParameterChange('right', parseFloat(e.target.value) || 0)}
              className="w-24 h-8 text-xs font-mono text-blue-600 font-semibold"
            />
          </div>
          <div className="flex justify-between items-center">
            <Label htmlFor="xincr" className="text-xs text-gray-600">X Interval (m):</Label>
            <Input
              id="xincr"
              type="number"
              step="0.1"
              value={parameters.xincr}
              onChange={(e) => handleParameterChange('xincr', parseFloat(e.target.value) || 0)}
              className="w-20 h-8 text-xs font-mono text-blue-600 font-semibold"
            />
          </div>
          <div className="flex justify-between items-center">
            <Label htmlFor="yincr" className="text-xs text-gray-600">Y Interval (m):</Label>
            <Input
              id="yincr"
              type="number"
              step="0.1"
              value={parameters.yincr}
              onChange={(e) => handleParameterChange('yincr', parseFloat(e.target.value) || 0)}
              className="w-20 h-8 text-xs font-mono text-blue-600 font-semibold"
            />
          </div>
          <div className="flex justify-between items-center">
            <Label htmlFor="noch" className="text-xs text-gray-600">No. of Chainages:</Label>
            <Input
              id="noch"
              type="number"
              value={parameters.noch}
              onChange={(e) => handleParameterChange('noch', parseInt(e.target.value) || 0)}
              className="w-20 h-8 text-xs font-mono text-blue-600 font-semibold"
            />
          </div>
        </div>
      </div>

      {/* Calculated Values */}
      <div className="bg-blue-50 p-3 rounded-lg border border-blue-200">
        <h3 className="text-sm font-semibold text-blue-800 mb-3">Calculated Values</h3>
        <div className="space-y-1">
          <div className="flex justify-between">
            <span className="text-xs text-blue-700">VVS:</span>
            <span className="text-xs font-mono text-blue-900 font-semibold">{parameters.vvs.toFixed(1)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-xs text-blue-700">HHS:</span>
            <span className="text-xs font-mono text-blue-900 font-semibold">{parameters.hhs.toFixed(1)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-xs text-blue-700">Scale Ratio:</span>
            <span className="text-xs font-mono text-blue-900 font-semibold">{parameters.sc.toFixed(1)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-xs text-blue-700">Skew (rad):</span>
            <span className="text-xs font-mono text-blue-900 font-semibold">{parameters.skew1.toFixed(4)}</span>
          </div>
        </div>
      </div>

      {/* Cross-Section Data */}
      <div>
        <h3 className="text-sm font-semibold text-gray-700 mb-3">Cross-Section Data</h3>
        <div className="max-h-40 overflow-y-auto">
          <table className="w-full text-xs">
            <thead className="bg-gray-100 sticky top-0">
              <tr>
                <th className="px-2 py-1 text-left font-semibold text-gray-700">Ch.</th>
                <th className="px-2 py-1 text-left font-semibold text-gray-700">RL</th>
                <th className="px-2 py-1 text-left font-semibold text-gray-700">Type</th>
              </tr>
            </thead>
            <tbody>
              {crossSections.map((section, index) => (
                <tr key={index} className="border-b border-gray-200 hover:bg-gray-50">
                  <td className="px-2 py-1 font-mono text-blue-600">{section.chainage.toFixed(2)}</td>
                  <td className="px-2 py-1 font-mono text-blue-600">{section.level.toFixed(2)}</td>
                  <td className="px-2 py-1 text-gray-600">{section.type || 'Ground'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <Button
          onClick={onCrossSectionAdd}
          variant="ghost"
          className="w-full mt-3 bg-gray-200 text-gray-700 hover:bg-gray-300 text-sm h-8"
        >
          <Plus className="h-4 w-4 mr-1" />
          Add Cross-Section
        </Button>
      </div>
    </div>
  );
}
