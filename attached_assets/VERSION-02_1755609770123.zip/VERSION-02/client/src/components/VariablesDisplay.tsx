import React from 'react';
import { BridgeParameters, CrossSection } from '@/types/bridge';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';

interface VariablesDisplayProps {
  parameters: BridgeParameters;
  crossSections: CrossSection[];
}

export function VariablesDisplay({ parameters, crossSections }: VariablesDisplayProps) {
  return (
    <Card className="w-full">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-semibold text-gray-900 flex items-center gap-2">
          <Badge variant="secondary" className="text-xs">Live Data</Badge>
          All Bridge Variables
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="grid grid-cols-2 gap-4 text-xs">
          {/* Input Parameters */}
          <div className="space-y-3">
            <div>
              <h4 className="font-semibold text-gray-800 mb-2">Input Parameters</h4>
              <div className="space-y-1">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Scale1 (Plan/Elev):</span>
                  <span className="font-mono text-blue-600 font-semibold bg-blue-50 px-2 py-1 rounded">
                    {parameters.scale1}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Scale2 (Section):</span>
                  <span className="font-mono text-blue-600 font-semibold bg-blue-50 px-2 py-1 rounded">
                    {parameters.scale2}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Skew Angle (°):</span>
                  <span className="font-mono text-blue-600 font-semibold bg-blue-50 px-2 py-1 rounded">
                    {parameters.skew.toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Datum Level (m):</span>
                  <span className="font-mono text-blue-600 font-semibold bg-blue-50 px-2 py-1 rounded">
                    {parameters.datum.toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Top RL (m):</span>
                  <span className="font-mono text-blue-600 font-semibold bg-blue-50 px-2 py-1 rounded">
                    {parameters.toprl.toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Left Chainage (m):</span>
                  <span className="font-mono text-blue-600 font-semibold bg-blue-50 px-2 py-1 rounded">
                    {parameters.left.toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Right Chainage (m):</span>
                  <span className="font-mono text-blue-600 font-semibold bg-blue-50 px-2 py-1 rounded">
                    {parameters.right.toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">X Increment (m):</span>
                  <span className="font-mono text-blue-600 font-semibold bg-blue-50 px-2 py-1 rounded">
                    {parameters.xincr.toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Y Increment (m):</span>
                  <span className="font-mono text-blue-600 font-semibold bg-blue-50 px-2 py-1 rounded">
                    {parameters.yincr.toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">No. of Chainages:</span>
                  <span className="font-mono text-blue-600 font-semibold bg-blue-50 px-2 py-1 rounded">
                    {parameters.noch}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Calculated Values */}
          <div className="space-y-3">
            <div>
              <h4 className="font-semibold text-gray-800 mb-2">Calculated Values</h4>
              <div className="space-y-1">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">HS (H Scale):</span>
                  <span className="font-mono text-green-600 font-semibold bg-green-50 px-2 py-1 rounded">
                    {parameters.hs.toFixed(3)}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">VS (V Scale):</span>
                  <span className="font-mono text-green-600 font-semibold bg-green-50 px-2 py-1 rounded">
                    {parameters.vs.toFixed(3)}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">VVS (V Convert):</span>
                  <span className="font-mono text-green-600 font-semibold bg-green-50 px-2 py-1 rounded">
                    {parameters.vvs.toFixed(1)}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">HHS (H Convert):</span>
                  <span className="font-mono text-green-600 font-semibold bg-green-50 px-2 py-1 rounded">
                    {parameters.hhs.toFixed(1)}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Skew1 (Radians):</span>
                  <span className="font-mono text-green-600 font-semibold bg-green-50 px-2 py-1 rounded">
                    {parameters.skew1.toFixed(4)}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Sin(Skew):</span>
                  <span className="font-mono text-green-600 font-semibold bg-green-50 px-2 py-1 rounded">
                    {parameters.s.toFixed(4)}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Cos(Skew):</span>
                  <span className="font-mono text-green-600 font-semibold bg-green-50 px-2 py-1 rounded">
                    {parameters.c.toFixed(4)}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Tan(Skew):</span>
                  <span className="font-mono text-green-600 font-semibold bg-green-50 px-2 py-1 rounded">
                    {parameters.tn.toFixed(4)}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Scale Ratio:</span>
                  <span className="font-mono text-green-600 font-semibold bg-green-50 px-2 py-1 rounded">
                    {parameters.sc.toFixed(2)}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <Separator className="my-4" />

        {/* Cross-Section Summary */}
        <div>
          <h4 className="font-semibold text-gray-800 mb-2 text-xs">Cross-Section Summary</h4>
          <div className="grid grid-cols-3 gap-2 text-xs">
            <div className="text-center p-2 bg-gray-50 rounded">
              <div className="font-mono text-lg font-bold text-blue-600">{crossSections.length}</div>
              <div className="text-gray-600">Total Points</div>
            </div>
            <div className="text-center p-2 bg-gray-50 rounded">
              <div className="font-mono text-lg font-bold text-green-600">
                {crossSections.length > 0 ? Math.min(...crossSections.map(cs => cs.level)).toFixed(2) : '0.00'}
              </div>
              <div className="text-gray-600">Min Level</div>
            </div>
            <div className="text-center p-2 bg-gray-50 rounded">
              <div className="font-mono text-lg font-bold text-orange-600">
                {crossSections.length > 0 ? Math.max(...crossSections.map(cs => cs.level)).toFixed(2) : '0.00'}
              </div>
              <div className="text-gray-600">Max Level</div>
            </div>
          </div>
        </div>

        {/* Range Information */}
        <Separator className="my-4" />
        <div>
          <h4 className="font-semibold text-gray-800 mb-2 text-xs">Drawing Range</h4>
          <div className="grid grid-cols-2 gap-3 text-xs">
            <div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Chainage Range:</span>
                <span className="font-mono text-purple-600 font-semibold">
                  {(parameters.right - parameters.left).toFixed(2)}m
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Level Range:</span>
                <span className="font-mono text-purple-600 font-semibold">
                  {(parameters.toprl - parameters.datum).toFixed(2)}m
                </span>
              </div>
            </div>
            <div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Grid Cells X:</span>
                <span className="font-mono text-purple-600 font-semibold">
                  {Math.ceil((parameters.right - parameters.left) / parameters.xincr)}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Grid Cells Y:</span>
                <span className="font-mono text-purple-600 font-semibold">
                  {Math.ceil((parameters.toprl - parameters.datum) / parameters.yincr)}
                </span>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}