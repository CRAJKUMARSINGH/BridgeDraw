import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { ExportOptions } from '@/types/bridge';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onExport: (options: ExportOptions) => void;
}

export function ExportModal({ isOpen, onClose, onExport }: ExportModalProps) {
  const [options, setOptions] = useState<ExportOptions>({
    paperSize: 'A4',
    orientation: 'landscape',
    includeTitleBlock: true,
    includeScaleInfo: true,
    includeGridLines: true,
    includeDataTable: false
  });

  const handleExport = () => {
    onExport(options);
    onClose();
  };

  const updateOptions = (updates: Partial<ExportOptions>) => {
    setOptions(prev => ({ ...prev, ...updates }));
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Export Options</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div>
            <Label className="text-sm font-medium text-gray-700 mb-2 block">
              Paper Size
            </Label>
            <Select
              value={options.paperSize}
              onValueChange={(value: any) => updateOptions({ paperSize: value })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="A4">A4 (210 × 297 mm)</SelectItem>
                <SelectItem value="A3">A3 (297 × 420 mm)</SelectItem>
                <SelectItem value="A2">A2 (420 × 594 mm)</SelectItem>
                <SelectItem value="A1">A1 (594 × 841 mm)</SelectItem>
                <SelectItem value="A0">A0 (841 × 1189 mm)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label className="text-sm font-medium text-gray-700 mb-2 block">
              Orientation
            </Label>
            <RadioGroup
              value={options.orientation}
              onValueChange={(value: 'landscape' | 'portrait') => 
                updateOptions({ orientation: value })
              }
              className="flex space-x-4"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="landscape" id="landscape" />
                <Label htmlFor="landscape" className="text-sm">Landscape</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="portrait" id="portrait" />
                <Label htmlFor="portrait" className="text-sm">Portrait</Label>
              </div>
            </RadioGroup>
          </div>

          <div>
            <Label className="text-sm font-medium text-gray-700 mb-2 block">
              Include
            </Label>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="titleBlock"
                  checked={options.includeTitleBlock}
                  onCheckedChange={(checked) => 
                    updateOptions({ includeTitleBlock: !!checked })
                  }
                />
                <Label htmlFor="titleBlock" className="text-sm">Title Block</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="scaleInfo"
                  checked={options.includeScaleInfo}
                  onCheckedChange={(checked) => 
                    updateOptions({ includeScaleInfo: !!checked })
                  }
                />
                <Label htmlFor="scaleInfo" className="text-sm">Scale Information</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="gridLines"
                  checked={options.includeGridLines}
                  onCheckedChange={(checked) => 
                    updateOptions({ includeGridLines: !!checked })
                  }
                />
                <Label htmlFor="gridLines" className="text-sm">Grid Lines</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="dataTable"
                  checked={options.includeDataTable}
                  onCheckedChange={(checked) => 
                    updateOptions({ includeDataTable: !!checked })
                  }
                />
                <Label htmlFor="dataTable" className="text-sm">Data Variables Table</Label>
              </div>
            </div>
          </div>
        </div>

        <DialogFooter className="flex justify-end space-x-3">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleExport}>
            Export
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
