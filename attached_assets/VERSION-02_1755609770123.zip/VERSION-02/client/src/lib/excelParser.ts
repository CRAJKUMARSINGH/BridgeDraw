import * as XLSX from 'xlsx';
import { BridgeParameters, CrossSection } from '@/types/bridge';

export interface ParsedExcelData {
  parameters: BridgeParameters;
  crossSections: CrossSection[];
}

export function parseExcelFile(file: File): Promise<ParsedExcelData> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 }) as any[][];
        
        const parsed = parseEngineeringData(jsonData);
        resolve(parsed);
      } catch (error) {
        reject(new Error('Failed to parse Excel file: ' + (error as Error).message));
      }
    };
    
    reader.onerror = () => {
      reject(new Error('Failed to read file'));
    };
    
    reader.readAsArrayBuffer(file);
  });
}

function parseEngineeringData(data: any[][]): ParsedExcelData {
  let rowIndex = 0;
  
  if (!data || data.length === 0) {
    throw new Error('Excel file is empty');
  }

  try {
    // Parse parameters in the same order as LISP code
    const scale1 = parseFloat(data[rowIndex++]?.[0]) || 100;
    const scale2 = parseFloat(data[rowIndex++]?.[0]) || 50;
    const skew = parseFloat(data[rowIndex++]?.[0]) || 0;
    const datum = parseFloat(data[rowIndex++]?.[0]) || 100;
    const toprl = parseFloat(data[rowIndex++]?.[0]) || 105;
    const left = parseFloat(data[rowIndex++]?.[0]) || 0;
    const right = parseFloat(data[rowIndex++]?.[0]) || 50;
    const xincr = parseFloat(data[rowIndex++]?.[0]) || 5;
    const yincr = parseFloat(data[rowIndex++]?.[0]) || 1;
    const noch = parseInt(data[rowIndex++]?.[0]) || 11;

    // Calculate derived values
    const hs = 1;
    const vs = 1;
    const vvs = 1000.0 / vs;
    const hhs = 1000.0 / hs;
    const skew1 = skew * 0.0174532; // Convert to radians
    const s = Math.sin(skew1);
    const c = Math.cos(skew1);
    const tn = s / c;
    const sc = scale1 / scale2;

    const parameters: BridgeParameters = {
      scale1,
      scale2,
      skew,
      datum,
      toprl,
      left,
      right,
      xincr,
      yincr,
      noch,
      hs,
      vs,
      vvs,
      hhs,
      skew1,
      s,
      c,
      tn,
      sc
    };

    // Parse cross-section data
    const crossSections: CrossSection[] = [];
    for (let i = 0; i < noch && rowIndex < data.length - 1; i++) {
      const chainage = parseFloat(data[rowIndex++]?.[0]) || 0;
      const level = parseFloat(data[rowIndex++]?.[0]) || 0;
      
      crossSections.push({
        chainage,
        level,
        type: 'Ground' // Default type, can be enhanced later
      });
    }

    return {
      parameters,
      crossSections
    };
  } catch (error) {
    throw new Error('Invalid Excel data format. Please ensure data is in the correct format.');
  }
}

export function validateExcelData(data: ParsedExcelData): string[] {
  const errors: string[] = [];
  
  // Validate parameters
  if (data.parameters.scale1 <= 0) errors.push("Plan/Elevation scale must be positive");
  if (data.parameters.scale2 <= 0) errors.push("Section scale must be positive");
  if (data.parameters.left >= data.parameters.right) errors.push("Start chainage must be less than end chainage");
  if (data.parameters.datum >= data.parameters.toprl) errors.push("Datum level must be less than top RL");
  if (data.parameters.xincr <= 0) errors.push("X interval must be positive");
  if (data.parameters.yincr <= 0) errors.push("Y interval must be positive");
  if (data.parameters.noch <= 0) errors.push("Number of chainages must be positive");
  
  // Validate cross-sections
  if (data.crossSections.length !== data.parameters.noch) {
    errors.push(`Expected ${data.parameters.noch} cross-sections, found ${data.crossSections.length}`);
  }
  
  data.crossSections.forEach((section, index) => {
    if (isNaN(section.chainage)) errors.push(`Invalid chainage at cross-section ${index + 1}`);
    if (isNaN(section.level)) errors.push(`Invalid level at cross-section ${index + 1}`);
  });
  
  return errors;
}
