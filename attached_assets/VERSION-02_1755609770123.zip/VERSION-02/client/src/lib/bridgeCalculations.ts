import { BridgeParameters, CrossSection } from '@/types/bridge';

export class BridgeCalculations {
  private params: BridgeParameters;

  constructor(params: BridgeParameters) {
    this.params = params;
  }

  get parameters(): BridgeParameters {
    return this.params;
  }

  // Coordinate transformation functions from LISP code
  vpos(a: number): number {
    const adjusted = this.params.vvs * (a - this.params.datum);
    return this.params.datum + adjusted;
  }

  hpos(a: number): number {
    const adjusted = this.params.hhs * (a - this.params.left);
    return this.params.left + adjusted;
  }

  v2pos(a: number): number {
    let adjusted = this.params.vvs * (a - this.params.datum);
    adjusted = this.params.sc * adjusted;
    return this.params.datum + adjusted;
  }

  h2pos(a: number): number {
    let adjusted = this.params.hhs * (a - this.params.left);
    adjusted = this.params.sc * adjusted;
    return this.params.left + adjusted;
  }

  // Calculate canvas coordinates from engineering coordinates
  toCanvasCoords(chainage: number, level: number, canvasWidth: number, canvasHeight: number): { x: number, y: number } {
    const margin = 50;
    const drawingWidth = canvasWidth - 2 * margin;
    const drawingHeight = canvasHeight - 2 * margin;

    // Scale chainage to canvas width
    const chainageRange = this.params.right - this.params.left;
    const x = margin + (chainage - this.params.left) / chainageRange * drawingWidth;

    // Scale level to canvas height (inverted Y axis)
    const levelRange = this.params.toprl - this.params.datum;
    const y = canvasHeight - margin - (level - this.params.datum) / levelRange * drawingHeight;

    return { x, y };
  }

  // Calculate engineering coordinates from canvas coordinates
  fromCanvasCoords(x: number, y: number, canvasWidth: number, canvasHeight: number): { chainage: number, level: number } {
    const margin = 50;
    const drawingWidth = canvasWidth - 2 * margin;
    const drawingHeight = canvasHeight - 2 * margin;

    const chainageRange = this.params.right - this.params.left;
    const chainage = this.params.left + (x - margin) / drawingWidth * chainageRange;

    const levelRange = this.params.toprl - this.params.datum;
    const level = this.params.datum + (canvasHeight - margin - y) / drawingHeight * levelRange;

    return { chainage, level };
  }

  // Update calculated parameters
  updateCalculatedValues(): BridgeParameters {
    const updatedParams = { ...this.params };
    
    updatedParams.hs = 1;
    updatedParams.vs = 1;
    updatedParams.vvs = 1000.0 / updatedParams.vs;
    updatedParams.hhs = 1000.0 / updatedParams.hs;
    updatedParams.skew1 = updatedParams.skew * 0.0174532;
    updatedParams.s = Math.sin(updatedParams.skew1);
    updatedParams.c = Math.cos(updatedParams.skew1);
    updatedParams.tn = updatedParams.s / updatedParams.c;
    updatedParams.sc = updatedParams.scale1 / updatedParams.scale2;

    this.params = updatedParams;
    return updatedParams;
  }

  // Generate grid lines for drawing
  generateGridLines(canvasWidth: number, canvasHeight: number): { xLines: Array<{x: number, label: string}>, yLines: Array<{y: number, label: string}> } {
    const xLines: Array<{x: number, label: string}> = [];
    const yLines: Array<{y: number, label: string}> = [];

    // X-axis grid lines (chainages)
    for (let ch = this.params.left; ch <= this.params.right; ch += this.params.xincr) {
      const coords = this.toCanvasCoords(ch, this.params.datum, canvasWidth, canvasHeight);
      xLines.push({ x: coords.x, label: ch.toFixed(1) });
    }

    // Y-axis grid lines (levels)
    for (let level = this.params.datum; level <= this.params.toprl; level += this.params.yincr) {
      const coords = this.toCanvasCoords(this.params.left, level, canvasWidth, canvasHeight);
      yLines.push({ y: coords.y, label: level.toFixed(1) });
    }

    return { xLines, yLines };
  }

  // Validate parameters
  validateParameters(): string[] {
    const errors: string[] = [];

    if (this.params.scale1 <= 0) errors.push("Plan/Elevation scale must be positive");
    if (this.params.scale2 <= 0) errors.push("Section scale must be positive");
    if (this.params.left >= this.params.right) errors.push("Start chainage must be less than end chainage");
    if (this.params.datum >= this.params.toprl) errors.push("Datum level must be less than top RL");
    if (this.params.xincr <= 0) errors.push("X interval must be positive");
    if (this.params.yincr <= 0) errors.push("Y interval must be positive");
    if (this.params.noch <= 0) errors.push("Number of chainages must be positive");

    return errors;
  }
}
