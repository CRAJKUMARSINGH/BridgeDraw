import { BridgeParameters, CrossSection, DrawingConfig } from '@/types/bridge';
import { BridgeCalculations } from './bridgeCalculations';

export class DrawingEngine {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private calculations: BridgeCalculations;
  private config: DrawingConfig;

  constructor(canvas: HTMLCanvasElement, params: BridgeParameters) {
    this.canvas = canvas;
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Canvas 2D context not available');
    this.ctx = ctx;
    this.calculations = new BridgeCalculations(params);
    this.config = {
      viewType: 'elevation',
      zoom: 1,
      panX: 0,
      panY: 0,
      showGrid: true,
      showDimensions: true
    };
  }

  updateParameters(params: BridgeParameters): void {
    this.calculations = new BridgeCalculations(params);
    this.draw();
  }

  updateConfig(config: Partial<DrawingConfig>): void {
    this.config = { ...this.config, ...config };
    this.draw();
  }

  clear(): void {
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
  }

  draw(crossSections: CrossSection[] = []): void {
    this.clear();
    
    // Set up drawing context
    this.ctx.save();
    this.ctx.scale(this.config.zoom, this.config.zoom);
    this.ctx.translate(this.config.panX, this.config.panY);

    // Draw based on view type
    switch (this.config.viewType) {
      case 'elevation':
        this.drawElevationView(crossSections);
        break;
      case 'plan':
        this.drawPlanView(crossSections);
        break;
      case 'section':
        this.drawSectionView(crossSections);
        break;
    }

    this.ctx.restore();
  }

  private drawElevationView(crossSections: CrossSection[]): void {
    // Draw Bridge GAD (General Arrangement Drawing) - Elevation View
    if (this.config.showGrid) {
      this.drawGrid();
    }
    this.drawAxes();
    this.drawCrossSectionProfile(crossSections);
    this.drawBridgeStructure(crossSections);
    if (this.config.showDimensions) {
      this.drawDimensions(crossSections);
    }
    this.drawTitleBlock();
  }

  private drawPlanView(crossSections: CrossSection[]): void {
    if (this.config.showGrid) {
      this.drawGrid();
    }
    this.drawAxes();
    // Plan view specific drawing logic
    this.drawPlanElements(crossSections);
  }

  private drawSectionView(crossSections: CrossSection[]): void {
    if (this.config.showGrid) {
      this.drawGrid();
    }
    this.drawAxes();
    // Section view specific drawing logic
    this.drawSectionElements(crossSections);
  }

  private drawGrid(): void {
    const { xLines, yLines } = this.calculations.generateGridLines(this.canvas.width, this.canvas.height);
    
    this.ctx.strokeStyle = '#e0e0e0';
    this.ctx.lineWidth = 1;
    
    // Draw vertical grid lines
    xLines.forEach(line => {
      this.ctx.beginPath();
      this.ctx.moveTo(line.x, 50);
      this.ctx.lineTo(line.x, this.canvas.height - 50);
      this.ctx.stroke();
    });

    // Draw horizontal grid lines
    yLines.forEach(line => {
      this.ctx.beginPath();
      this.ctx.moveTo(50, line.y);
      this.ctx.lineTo(this.canvas.width - 50, line.y);
      this.ctx.stroke();
    });
  }

  private drawAxes(): void {
    const margin = 50;
    const arrowSize = 10;

    // Set axis style
    this.ctx.strokeStyle = '#1976D2';
    this.ctx.lineWidth = 2;
    this.ctx.fillStyle = '#1976D2';

    // X-axis
    this.ctx.beginPath();
    this.ctx.moveTo(margin, this.canvas.height - margin);
    this.ctx.lineTo(this.canvas.width - margin, this.canvas.height - margin);
    this.ctx.stroke();

    // X-axis arrow
    this.ctx.beginPath();
    this.ctx.moveTo(this.canvas.width - margin, this.canvas.height - margin);
    this.ctx.lineTo(this.canvas.width - margin - arrowSize, this.canvas.height - margin - arrowSize/2);
    this.ctx.lineTo(this.canvas.width - margin - arrowSize, this.canvas.height - margin + arrowSize/2);
    this.ctx.closePath();
    this.ctx.fill();

    // Y-axis
    this.ctx.beginPath();
    this.ctx.moveTo(margin, this.canvas.height - margin);
    this.ctx.lineTo(margin, margin);
    this.ctx.stroke();

    // Y-axis arrow
    this.ctx.beginPath();
    this.ctx.moveTo(margin, margin);
    this.ctx.lineTo(margin - arrowSize/2, margin + arrowSize);
    this.ctx.lineTo(margin + arrowSize/2, margin + arrowSize);
    this.ctx.closePath();
    this.ctx.fill();

    // Axis labels
    this.ctx.font = '14px Roboto';
    this.ctx.fillText('Chainage (m)', this.canvas.width - 100, this.canvas.height - 20);
    
    this.ctx.save();
    this.ctx.translate(20, this.canvas.height / 2);
    this.ctx.rotate(-Math.PI / 2);
    this.ctx.fillText('RL (m)', -40, 0);
    this.ctx.restore();

    // Draw grid labels
    this.drawGridLabels();
  }

  private drawGridLabels(): void {
    const { xLines, yLines } = this.calculations.generateGridLines(this.canvas.width, this.canvas.height);
    
    this.ctx.font = '10px Roboto Mono';
    this.ctx.fillStyle = '#666';
    this.ctx.textAlign = 'center';

    // X-axis labels
    xLines.forEach(line => {
      this.ctx.fillText(line.label, line.x, this.canvas.height - 30);
    });

    this.ctx.textAlign = 'right';
    // Y-axis labels
    yLines.forEach(line => {
      this.ctx.fillText(line.label, 40, line.y + 4);
    });

    this.ctx.textAlign = 'start'; // Reset text alignment
  }

  private drawCrossSectionProfile(crossSections: CrossSection[]): void {
    if (crossSections.length < 2) return;

    // Draw Bridge GAD ground line
    this.ctx.strokeStyle = '#8B4513';
    this.ctx.lineWidth = 3;
    this.ctx.beginPath();

    const firstPoint = this.calculations.toCanvasCoords(
      crossSections[0].chainage,
      crossSections[0].level,
      this.canvas.width,
      this.canvas.height
    );
    this.ctx.moveTo(firstPoint.x, firstPoint.y);

    crossSections.forEach((section, index) => {
      if (index === 0) return;
      
      const point = this.calculations.toCanvasCoords(
        section.chainage,
        section.level,
        this.canvas.width,
        this.canvas.height
      );
      this.ctx.lineTo(point.x, point.y);
    });

    this.ctx.stroke();

    // Mark cross-section points with chainage labels
    this.ctx.fillStyle = '#D32F2F';
    crossSections.forEach(section => {
      const point = this.calculations.toCanvasCoords(
        section.chainage,
        section.level,
        this.canvas.width,
        this.canvas.height
      );
      this.ctx.beginPath();
      this.ctx.arc(point.x, point.y, 4, 0, 2 * Math.PI);
      this.ctx.fill();
      
      // Add chainage labels
      this.ctx.fillStyle = '#1976D2';
      this.ctx.font = '10px Roboto Mono';
      this.ctx.textAlign = 'center';
      this.ctx.fillText(section.chainage.toFixed(1), point.x, point.y - 8);
      this.ctx.fillStyle = '#D32F2F';
    });
  }



  private drawBridgeStructure(crossSections: CrossSection[]): void {
    // Draw bridge structural elements based on LISP GAD requirements
    if (crossSections.length === 0) return;

    const bridgePoints = crossSections.filter(cs => cs.type === 'Bridge' || cs.level > this.calculations.parameters.datum + 1);
    
    if (bridgePoints.length < 2) return;

    // Draw bridge deck
    this.ctx.strokeStyle = '#2E7D32';
    this.ctx.lineWidth = 6;
    this.ctx.lineCap = 'round';
    this.ctx.beginPath();

    bridgePoints.forEach((point, index) => {
      const canvasPoint = this.calculations.toCanvasCoords(
        point.chainage,
        point.level + 0.5, // Bridge deck height above ground
        this.canvas.width,
        this.canvas.height
      );
      
      if (index === 0) {
        this.ctx.moveTo(canvasPoint.x, canvasPoint.y);
      } else {
        this.ctx.lineTo(canvasPoint.x, canvasPoint.y);
      }
    });
    this.ctx.stroke();

    // Draw bridge piers/supports
    bridgePoints.forEach(point => {
      const groundPoint = this.calculations.toCanvasCoords(
        point.chainage,
        point.level,
        this.canvas.width,
        this.canvas.height
      );
      const deckPoint = this.calculations.toCanvasCoords(
        point.chainage,
        point.level + 0.5,
        this.canvas.width,
        this.canvas.height
      );

      this.ctx.strokeStyle = '#424242';
      this.ctx.lineWidth = 4;
      this.ctx.beginPath();
      this.ctx.moveTo(groundPoint.x, groundPoint.y);
      this.ctx.lineTo(deckPoint.x, deckPoint.y);
      this.ctx.stroke();
    });
  }

  private drawDimensions(crossSections: CrossSection[]): void {
    // Draw dimension lines with measurements as per LISP GAD standards
    if (crossSections.length < 2) return;

    this.ctx.strokeStyle = '#666';
    this.ctx.lineWidth = 1;
    this.ctx.fillStyle = '#666';
    this.ctx.font = '9px Roboto';
    this.ctx.textAlign = 'center';

    // Horizontal dimensions between chainages
    for (let i = 0; i < crossSections.length - 1; i++) {
      const point1 = this.calculations.toCanvasCoords(
        crossSections[i].chainage,
        crossSections[i].level,
        this.canvas.width,
        this.canvas.height
      );
      const point2 = this.calculations.toCanvasCoords(
        crossSections[i + 1].chainage,
        crossSections[i + 1].level,
        this.canvas.width,
        this.canvas.height
      );

      const dimY = Math.min(point1.y, point2.y) - 30;
      const distance = crossSections[i + 1].chainage - crossSections[i].chainage;

      // Dimension line
      this.ctx.beginPath();
      this.ctx.moveTo(point1.x, dimY);
      this.ctx.lineTo(point2.x, dimY);
      this.ctx.stroke();

      // Extension lines
      this.ctx.beginPath();
      this.ctx.moveTo(point1.x, point1.y - 10);
      this.ctx.lineTo(point1.x, dimY + 5);
      this.ctx.moveTo(point2.x, point2.y - 10);
      this.ctx.lineTo(point2.x, dimY + 5);
      this.ctx.stroke();

      // Dimension text
      const midX = (point1.x + point2.x) / 2;
      this.ctx.fillText(`${distance.toFixed(1)}m`, midX, dimY - 5);
    }

    // Vertical dimensions for key levels
    const leftmostPoint = crossSections[0];
    const rightmostPoint = crossSections[crossSections.length - 1];
    
    if (leftmostPoint && rightmostPoint) {
      const leftCanvas = this.calculations.toCanvasCoords(
        leftmostPoint.chainage,
        leftmostPoint.level,
        this.canvas.width,
        this.canvas.height
      );
      const datumCanvas = this.calculations.toCanvasCoords(
        leftmostPoint.chainage,
        this.calculations.parameters.datum,
        this.canvas.width,
        this.canvas.height
      );

      const dimX = leftCanvas.x - 40;
      const levelDiff = leftmostPoint.level - this.calculations.parameters.datum;

      // Vertical dimension line
      this.ctx.beginPath();
      this.ctx.moveTo(dimX, leftCanvas.y);
      this.ctx.lineTo(dimX, datumCanvas.y);
      this.ctx.stroke();

      // Extension lines
      this.ctx.beginPath();
      this.ctx.moveTo(leftCanvas.x - 10, leftCanvas.y);
      this.ctx.lineTo(dimX + 5, leftCanvas.y);
      this.ctx.moveTo(leftCanvas.x - 10, datumCanvas.y);
      this.ctx.lineTo(dimX + 5, datumCanvas.y);
      this.ctx.stroke();

      // Dimension text
      this.ctx.save();
      this.ctx.translate(dimX - 10, (leftCanvas.y + datumCanvas.y) / 2);
      this.ctx.rotate(-Math.PI / 2);
      this.ctx.fillText(`${levelDiff.toFixed(2)}m`, 0, 0);
      this.ctx.restore();
    }
  }

  private drawTitleBlock(): void {
    // Draw title block as per engineering drawing standards
    const titleBlockX = this.canvas.width - 250;
    const titleBlockY = this.canvas.height - 100;
    const titleBlockWidth = 230;
    const titleBlockHeight = 80;

    // Title block border
    this.ctx.strokeStyle = '#000';
    this.ctx.lineWidth = 2;
    this.ctx.strokeRect(titleBlockX, titleBlockY, titleBlockWidth, titleBlockHeight);

    // Title block content
    this.ctx.fillStyle = '#000';
    this.ctx.font = 'bold 14px Roboto';
    this.ctx.textAlign = 'center';
    this.ctx.fillText('BRIDGE GENERAL ARRANGEMENT DRAWING', titleBlockX + titleBlockWidth/2, titleBlockY + 20);

    this.ctx.font = '10px Roboto';
    this.ctx.textAlign = 'left';
    this.ctx.fillText(`Scale: 1:${this.calculations.parameters.scale1}`, titleBlockX + 10, titleBlockY + 40);
    this.ctx.fillText(`Drawing No: GAD-001`, titleBlockX + 10, titleBlockY + 55);
    this.ctx.fillText(`Date: ${new Date().toLocaleDateString()}`, titleBlockX + 10, titleBlockY + 70);

    this.ctx.textAlign = 'right';
    this.ctx.fillText(`Skew: ${this.calculations.parameters.skew}°`, titleBlockX + titleBlockWidth - 10, titleBlockY + 40);
    this.ctx.fillText(`Datum: ${this.calculations.parameters.datum}m`, titleBlockX + titleBlockWidth - 10, titleBlockY + 55);
  }

  private drawPlanElements(crossSections: CrossSection[]): void {
    // Implementation for plan view elements
  }

  private drawSectionElements(crossSections: CrossSection[]): void {
    // Implementation for section view elements
  }

  // Export drawing as image data URL
  exportAsImage(): string {
    return this.canvas.toDataURL('image/png');
  }

  // Get cursor position in engineering coordinates
  getCursorPosition(clientX: number, clientY: number): { chainage: number, level: number } {
    const rect = this.canvas.getBoundingClientRect();
    const x = (clientX - rect.left) / this.config.zoom - this.config.panX;
    const y = (clientY - rect.top) / this.config.zoom - this.config.panY;
    
    return this.calculations.fromCanvasCoords(x, y, this.canvas.width, this.canvas.height);
  }
}
