// Bridge GAD (General Arrangement Drawing) Engine based on LISP code structure
export interface GADParameters {
  // Basic parameters
  scale1: number;           // Drawing scale
  datum: number;           // Datum level
  left: number;            // Left boundary chainage
  right: number;           // Right boundary chainage
  toprl: number;           // Top RL
  skew: number;            // Skew angle
  
  // Grid spacing
  d1: number;              // 20mm - Distance between parallel lines to X axis
  xincr: number;           // Chainage increment (e.g., 10.0)
  yincr: number;           // Level increment (e.g., 2.0)
  
  // Bridge data
  nspan: number;           // Number of spans
  lbridge: number;         // Length of bridge
  abtl: number;            // Chainage of left abutment
  RTL: number;             // Road top level
  sofl: number;            // Soffit level
  
  // Deck details
  kerbw: number;           // Width of kerb at deck top
  kerbd: number;           // Depth of kerb above deck top
  ccbr: number;            // Clear carriageway width of bridge
  slbthc: number;          // Thickness of slab at centre
  slbthe: number;          // Thickness of slab at edge
  slbtht: number;          // Thickness of slab at tip
  
  // Pier details
  capt: number;            // Pier cap top RL
  capb: number;            // Pier cap bottom RL
  capw: number;            // Cap width
  piertw: number;          // Pier top width
  battr: number;           // Pier batter
  pierst: number;          // Straight length of pier
  
  // Cross-section data
  crossSections: Array<{
    chainage: number;
    level: number;
  }>;
  
  // Span data
  spans: Array<{
    length: number;
    futrl: number;         // Founding RL of pier
    futd: number;          // Depth of footing
    futw: number;          // Width of footing
    futl: number;          // Length of footing
  }>;
}

export class BridgeGADEngine {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private params!: GADParameters;
  
  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d')!;
  }
  
  // Convert engineering coordinates to canvas coordinates
  private hpos(chainage: number): number {
    return (chainage - this.params.left) * this.params.scale1;
  }
  
  private vpos(level: number): number {
    return this.canvas.height - ((level - this.params.datum) * this.params.scale1);
  }
  
  // Main drawing function
  drawGAD(params: GADParameters): void {
    this.params = params;
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    
    // Set drawing properties
    this.ctx.strokeStyle = '#000000';
    this.ctx.fillStyle = '#000000';
    this.ctx.lineWidth = 1;
    this.ctx.font = '10px Arial';
    
    // Draw layout (axes and grid)
    this.drawLayout();
    
    // Draw cross-section
    this.drawCrossSection();
    
    // Draw bridge elements
    this.drawBridgeElements();
    
    // Draw title block
    this.drawTitleBlock();
  }
  
  // Layout function from LISP code
  private drawLayout(): void {
    const { left, datum, scale1, d1, right, toprl } = this.params;
    
    // Convert left to integer (as in LISP)
    const leftInt = Math.floor(left);
    
    // Calculate key points
    const pta1 = [this.hpos(leftInt), this.vpos(datum)];
    const pta2 = [this.hpos(right), this.vpos(datum)];
    const ptb1 = [this.hpos(leftInt), this.vpos(datum - d1 * scale1)];
    const ptb2 = [this.hpos(right), this.vpos(datum - d1 * scale1)];
    const ptc1 = [this.hpos(leftInt), this.vpos(datum - d1 * scale1 * 2)];
    const ptc2 = [this.hpos(right), this.vpos(datum - d1 * scale1 * 2)];
    const ptd1 = [this.hpos(leftInt), this.vpos(toprl)];
    
    // Draw X axis
    this.ctx.beginPath();
    this.ctx.moveTo(pta1[0], pta1[1]);
    this.ctx.lineTo(pta2[0], pta2[1]);
    this.ctx.stroke();
    
    // Draw parallel lines (20mm below)
    this.ctx.beginPath();
    this.ctx.moveTo(ptb1[0], ptb1[1]);
    this.ctx.lineTo(ptb2[0], ptb2[1]);
    this.ctx.stroke();
    
    // Draw parallel lines (40mm below)
    this.ctx.beginPath();
    this.ctx.moveTo(ptc1[0], ptc1[1]);
    this.ctx.lineTo(ptc2[0], ptc2[1]);
    this.ctx.stroke();
    
    // Draw Y axis
    this.ctx.beginPath();
    this.ctx.moveTo(ptc1[0], ptc1[1]);
    this.ctx.lineTo(ptd1[0], ptd1[1]);
    this.ctx.stroke();
    
    // Add axis labels
    this.ctx.fillText('BED LEVEL', leftInt - 25 * scale1, datum - d1 * 0.5 * scale1);
    this.ctx.fillText('CHAINAGE', leftInt - 25 * scale1, datum - d1 * 1.5 * scale1);
    
    // Draw grid marks and labels
    this.drawGridMarks();
  }
  
  private drawGridMarks(): void {
    const { left, datum, scale1, toprl, yincr, xincr, right } = this.params;
    const d2 = 2.5; // Half length of small line on Y axis
    
    // Y-axis marks and level labels
    const nov = Math.floor(toprl - datum);
    const n = Math.floor(nov / yincr);
    
    for (let a = 0; a <= n; a++) {
      const lvl = datum + (a * yincr);
      const pta1 = [this.hpos(left) - d2 * scale1, this.vpos(lvl)];
      const pta2 = [this.hpos(left) + d2 * scale1, this.vpos(lvl)];
      
      // Draw small marks
      this.ctx.beginPath();
      this.ctx.moveTo(pta1[0], pta1[1]);
      this.ctx.lineTo(pta2[0], pta2[1]);
      this.ctx.stroke();
      
      // Write level
      const levelText = lvl.toFixed(3);
      this.ctx.fillText(levelText, this.hpos(left) - 13 * scale1, this.vpos(lvl) - 1 * scale1);
    }
    
    // X-axis marks and chainage labels
    const noh = right - left;
    const nx = Math.floor(noh / xincr);
    
    for (let a = 1; a <= nx; a++) {
      const ch = left + (a * xincr);
      const chainageText = ch.toFixed(3);
      
      // Calculate positions for marks and text
      const d4 = 2 * d2; // distance between x axis and bottom line
      const d5 = d4 - 2.0; // small lines on x axis = 2mm
      const d6 = d2 + 2.0; // small vertical lines
      const d7 = d2 - 2.0;
      const d8 = d4 - 4.0; // chainage written 4mm above bottom line
      
      // Draw chainage text (rotated 90 degrees)
      this.ctx.save();
      this.ctx.translate(this.hpos(ch) + scale1, this.vpos(datum - d8 * scale1));
      this.ctx.rotate(Math.PI / 2);
      this.ctx.fillText(chainageText, 0, 0);
      this.ctx.restore();
      
      // Draw small marks
      this.ctx.beginPath();
      this.ctx.moveTo(this.hpos(ch), this.vpos(datum - d4 * scale1));
      this.ctx.lineTo(this.hpos(ch), this.vpos(datum - d5 * scale1));
      this.ctx.stroke();
      
      this.ctx.beginPath();
      this.ctx.moveTo(this.hpos(ch), this.vpos(datum - d6 * scale1));
      this.ctx.lineTo(this.hpos(ch), this.vpos(datum - d7 * scale1));
      this.ctx.stroke();
    }
  }
  
  // Cross-section function from LISP code
  private drawCrossSection(): void {
    if (!this.params.crossSections || this.params.crossSections.length === 0) return;
    
    let prevPoint: [number, number] | null = null;
    
    this.params.crossSections.forEach((cs, index) => {
      const xx = this.hpos(cs.chainage);
      const yy = this.vpos(cs.level);
      const currentPoint: [number, number] = [xx, yy];
      
      // Draw line from previous point
      if (prevPoint && index > 0) {
        this.ctx.beginPath();
        this.ctx.moveTo(prevPoint[0], prevPoint[1]);
        this.ctx.lineTo(currentPoint[0], currentPoint[1]);
        this.ctx.stroke();
      }
      
      // Write level text (rotated 90 degrees)
      this.ctx.save();
      this.ctx.translate(xx + 0.9 * this.params.scale1, this.vpos(this.params.datum - 16 * this.params.scale1));
      this.ctx.rotate(Math.PI / 2);
      this.ctx.fillText(cs.level.toFixed(3), 0, 0);
      this.ctx.restore();
      
      // Draw vertical marks to datum
      this.ctx.beginPath();
      this.ctx.moveTo(xx, this.vpos(this.params.datum - 2 * this.params.scale1));
      this.ctx.lineTo(xx, this.vpos(this.params.datum));
      this.ctx.stroke();
      
      prevPoint = currentPoint;
    });
  }
  
  // Bridge elements from LISP pier() function
  private drawBridgeElements(): void {
    if (!this.params.spans || this.params.spans.length === 0) return;
    
    let currentChainage = this.params.abtl;
    
    this.params.spans.forEach((span, index) => {
      const spanEnd = currentChainage + span.length;
      
      // Draw span (superstructure)
      this.drawSpan(currentChainage, spanEnd);
      
      // Draw pier at end of span (except for last span)
      if (index < this.params.spans.length - 1) {
        this.drawPier(spanEnd, span);
      }
      
      currentChainage = spanEnd;
    });
  }
  
  private drawSpan(start: number, end: number): void {
    const { RTL, sofl, scale1 } = this.params;
    
    const x1 = this.hpos(start);
    const y1 = this.vpos(RTL);
    const x2 = this.hpos(end);
    const y2 = this.vpos(sofl);
    
    // Draw span rectangle (25mm expansion gap)
    this.ctx.strokeRect(x1 + 25, y2, x2 - x1 - 50, y1 - y2);
    
    // Add span length dimension
    this.ctx.fillText(`L=${(end - start).toFixed(1)}m`, (x1 + x2) / 2, y1 + 50);
  }
  
  private drawPier(chainage: number, span: any): void {
    const { capb, capt, capw, piertw, battr, scale1 } = this.params;
    const c = Math.cos(this.params.skew * Math.PI / 180); // Skew factor
    
    const xc = this.hpos(chainage);
    
    // Draw pier cap
    const capwsq = capw / c;
    const capLeft = xc - capwsq / 2;
    const capRight = xc + capwsq / 2;
    this.ctx.strokeRect(
      this.hpos(capLeft), 
      this.vpos(capt), 
      this.hpos(capRight) - this.hpos(capLeft), 
      this.vpos(capb) - this.vpos(capt)
    );
    
    // Draw pier shaft with batter
    const piertwsq = piertw / c;
    const pierLeft = chainage - piertwsq / 2;
    const pierRight = chainage + piertwsq / 2;
    const pierBottom = span.futrl + span.futd;
    
    const offset = (capb - pierBottom) / battr;
    const offsetsq = offset / c;
    
    const pierBottomLeft = pierLeft - offsetsq;
    const pierBottomRight = pierRight + offsetsq;
    
    // Draw pier sides
    this.ctx.beginPath();
    this.ctx.moveTo(this.hpos(pierLeft), this.vpos(capb));
    this.ctx.lineTo(this.hpos(pierBottomLeft), this.vpos(pierBottom));
    this.ctx.stroke();
    
    this.ctx.beginPath();
    this.ctx.moveTo(this.hpos(pierRight), this.vpos(capb));
    this.ctx.lineTo(this.hpos(pierBottomRight), this.vpos(pierBottom));
    this.ctx.stroke();
    
    // Draw footing
    const futwsq = span.futw / c;
    const footingLeft = chainage - futwsq / 2;
    const footingRight = chainage + futwsq / 2;
    
    this.ctx.strokeRect(
      this.hpos(footingLeft),
      this.vpos(span.futrl),
      this.hpos(footingRight) - this.hpos(footingLeft),
      this.vpos(pierBottom) - this.vpos(span.futrl)
    );
    
    // Add dimensions
    this.ctx.fillText(`W=${capw.toFixed(1)}m`, this.hpos(chainage), this.vpos(capb) - 10);
    this.ctx.fillText(`D=${span.futd.toFixed(1)}m`, this.hpos(chainage), this.vpos(span.futrl) - 10);
  }
  
  private drawTitleBlock(): void {
    const titleBlockX = this.canvas.width - 300;
    const titleBlockY = 20;
    const titleBlockWidth = 280;
    const titleBlockHeight = 80;
    
    // Draw title block border
    this.ctx.strokeRect(titleBlockX, titleBlockY, titleBlockWidth, titleBlockHeight);
    
    // Title
    this.ctx.font = 'bold 14px Arial';
    this.ctx.textAlign = 'center';
    this.ctx.fillText('BRIDGE GENERAL ARRANGEMENT DRAWING', titleBlockX + titleBlockWidth/2, titleBlockY + 20);
    
    // Details
    this.ctx.font = '10px Arial';
    this.ctx.textAlign = 'left';
    this.ctx.fillText(`Scale: 1:${this.params.scale1}`, titleBlockX + 10, titleBlockY + 40);
    this.ctx.fillText(`Drawing No: GAD-001`, titleBlockX + 10, titleBlockY + 55);
    this.ctx.fillText(`Date: ${new Date().toLocaleDateString()}`, titleBlockX + 10, titleBlockY + 70);
    
    this.ctx.textAlign = 'right';
    this.ctx.fillText(`Skew: ${this.params.skew}°`, titleBlockX + titleBlockWidth - 10, titleBlockY + 40);
    this.ctx.fillText(`Datum: ${this.params.datum}m`, titleBlockX + titleBlockWidth - 10, titleBlockY + 55);
  }
}